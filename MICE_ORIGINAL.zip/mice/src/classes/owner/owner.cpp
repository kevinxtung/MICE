#include "owner.h"

Owner::Owner(std::string name, std::string phone)
    : Person(name, phone) { }