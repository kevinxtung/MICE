#include "container.h"

std::string Container::getType() const {return "Container";}

int Container::getMaxScoops() {return m_maxScoops;}
