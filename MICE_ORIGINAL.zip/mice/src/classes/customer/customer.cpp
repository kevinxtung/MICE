#include "customer.h"

Customer::Customer(std::string name, std::string phone)
    : Person(name, phone) { }