#include "manager.h"

Manager::Manager(std::string name, std::string phone)
    : Person(name, phone) { }