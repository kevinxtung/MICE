#include "scoop.h"

std::string Scoop::getType() const {return "Scoop";}
